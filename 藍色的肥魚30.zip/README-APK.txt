Blue Big Fish V30 Android project
Build workflow: .github/workflows/build-apk-v30.yml
Upload V30-Android-Project.zip to the repository root, then add the workflow file.
